"""Modules for creating and running a text recognizer."""
