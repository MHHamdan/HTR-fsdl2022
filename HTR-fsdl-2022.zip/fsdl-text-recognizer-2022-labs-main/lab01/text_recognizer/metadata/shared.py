from pathlib import Path

DATA_DIRNAME = Path(__file__).resolve().parents[3] / "data"
DOWNLOADED_DATA_DIRNAME = DATA_DIRNAME / "downloaded"
