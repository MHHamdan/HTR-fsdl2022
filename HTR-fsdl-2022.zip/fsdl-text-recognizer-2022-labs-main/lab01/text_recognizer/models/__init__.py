"""Models for character and text recognition in images."""
from .mlp import MLP
