"""Cloud function-backed API for paragraph recognition."""
