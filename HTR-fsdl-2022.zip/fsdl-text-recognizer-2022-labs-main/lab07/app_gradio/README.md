## Full-Paragraph Optical Character Recognition

For more on how this application works,
[check out the GitHub repo](https://github.com/full-stack-deep-learning/fsdl-text-recognizer-2022).

<!-- logging content below -->
### Flagging

If the model outputs in the top-right are wrong in some way,
let us know by clicking the "flagging" buttons underneath.

We'll analyze the results with
[Gantry](https://gantry.io/blog/introducing-gantry/)
and use them to improve the model!
