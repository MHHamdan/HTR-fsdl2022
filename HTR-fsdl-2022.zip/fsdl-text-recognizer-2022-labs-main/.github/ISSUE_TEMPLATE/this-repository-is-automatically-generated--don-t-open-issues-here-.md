---
name: This repository is automatically generated! Don't open issues here.
about: Open issues in the generating repo instead, at https://fsdl.me/2022-repo.
title: ''
labels: ''
assignees: ''

---

Thanks for your interest in contributing!

This repository is automatically generated from a source repo,
so the preferred place for issues and the only place for PRs is there.

So please open your issues [there](https://github.com/full-stack-deep-learning/fsdl-text-recognizer-2022).
Looking forward to hearing from you!
